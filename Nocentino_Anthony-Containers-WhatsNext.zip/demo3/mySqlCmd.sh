sqlcmd -S localhost,$1 -U sa -P 'S0methingS@Str0ng!' -i $2 -o /dev/null
